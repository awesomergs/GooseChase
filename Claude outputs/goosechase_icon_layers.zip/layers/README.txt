GooseChase icon layers (reference). All 1024x1024, same coordinates, so they stack aligned.
Icon Composer groups: 1 = grass | 2 = goose body + wing | 3 = beak, legs, eye | 4 = speed lines, brackets
Background: use Icon Composer's gradient fill (#3FA2E0 -> #5BB8EC) instead of 0_background_sky.svg.
Key dims: body oval 460x270 @ (470,610) | neck 78 px | head d=152 @ (702,318) | beak 128 long | legs 26 px | eye d=28 | grass top ~y805
